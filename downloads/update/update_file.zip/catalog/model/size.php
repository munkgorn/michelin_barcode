<?php 
	class SizeModel extends db {
		public function import($data=array()){
			$result = array();
			$file = $data['file'];
			$sql = "LOAD DATA LOCAL INFILE '" . DOCUMENT_ROOT . $file . "' INTO TABLE ".PREFIX."group FIELDS TERMINATED BY ',' 
			LINES TERMINATED BY '\n' IGNORE 1 ROWS ( id_user,group_code, remaining_qty,barcode_use,date_wk,date_added,date_modify);";
			$this->query($sql);
			return $result;
		}
	}
?>