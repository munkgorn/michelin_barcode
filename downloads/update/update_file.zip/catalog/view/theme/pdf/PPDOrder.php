<div class="container">
	<div class="row">
		<div class="col-12">
			<h3 class="text-center">BARCODE FOR PCLT</h3>
		</div>
	</div>
	<div class="row">
		<div class="col-4">
			<label for="">PART NO: </label>
		</div>
		<div class="col-4">
			<label for=""></label>
		</div>
		<div class="col-4">

		</div>
	</div>
	<div class="row">
		<div class="col-4">
			<label for="">BUYER: </label>
		</div>
		<div class="col-4">
			<label for=""></label>
		</div>
		<div class="col-4">

		</div>
	</div>
	<div class="row">
		<div class="col-3">
			<label for="">Order date: </label>
		</div>
		<div class="col-3">
			
		</div>
		<div class="col-3">
			<label for="">Needed Date:</label>
		</div>
		<div class="col-3">

		</div>
	</div>
	<div class="row">
		<div class="col-3">
			<label for="">1) DURARACK-PG PRINTED LABEL WIDETH = 7 mm. LENGTH = 32.60 mm.</label>
		</div>
	</div>
	<div class="row">
		<div class="col-6">
			<table class="table">
				<tr>
					<td>No.</td>
					<td>Start</td>
					<td>End</td>
					<td>Count.</td>
				</tr>
				<tr>
					<td>1</td>
					<td>17100000</td>
					<td>17117999</td>
					<td>18000</td>
				</tr>
			</table>
		</div>
		<div class="col-6">
			<table class="table">
				<tr>
					<td>No.</td>
					<td>Start</td>
					<td>End</td>
					<td>Count.</td>
				</tr>
			</table>
		</div>
	</div>
</div>
<style>
	.col-6 {
		width:400px;float:left;
	}
	table {
		width:800px;
	}
	table td {
		border: solid 1px #000;
	}
</style>