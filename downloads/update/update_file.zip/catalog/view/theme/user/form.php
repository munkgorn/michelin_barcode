<div class="page-wrapper">
	<div class="card">
		<div class="card-header">
			<h4 class="card-title">Add barcode</h4>
			<p class="text-muted mb-0">Add barcode</p>
		</div>
		<div class="card-body bootstrap-select-1">
			<form action="" id="formresult">
				<div class="row">
					<div class="col-3">
						<label class="mb-2">Username</label>
						<div class="">
							<input type="text" class="form-control" name="username" value="">
						</div>
					</div>
					<div class="col-3">
						<label class="mb-2">Password</label>
						<div class="">
							<input type="password" class="form-control" name="password" value="">
						</div>
					</div>
					<div class="col-3">
						<label class="mb-2">Group name</label>
						<div class="">
							<select name="id_user_group" id="" class="select2">
								<?php foreach($listUserGroup as $val){?>
								<option value="<?php echo $val['id_user_group']; ?>"><?php echo $val['group_name']; ?></option>
								<?php } ?>
							</select>
						</div>
					</div>
				</div>
				<div class="row mt-4">
					<div class="col-12">
						<div class="float-left">
							<a href="<?php echo route('user'); ?>" class="btn btn-default">back</a>
						</div>
						<div class="float-right">
							<input type="submit" value="Save" class="btn btn-primary">
						</div>
					</div>
				</div>
			</form>
		</div>
	</div>
</div>
