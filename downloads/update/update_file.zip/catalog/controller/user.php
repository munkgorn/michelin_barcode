<?php 
	class UserController extends Controller {
	    public function index() {
	    	$data = array();
	    	$data['title'] = "user";
	    	$user = $this->model('user');
	    	$listUser = $user->listUser();
	    	$data['listUser'] = $listUser;
 	    	$this->view('user/list',$data);
	    }
	    public function add() {
	    	$data = array();
	    	$data['title'] = "user";
	    	$user = $this->model('user');
	    	$listUserGroup = $user->listUserGroup();
	    	$data['listUserGroup'] = $listUserGroup;
 	    	$this->view('user/form',$data);
	    }
	    public function edit() {
	    	$data = array();
	    	$data['title'] = "user";
	    	$user = $this->model('user');
	    	$listUserGroup = $user->listUserGroup();
	    	$data['listUserGroup'] = $listUserGroup;
 	    	$this->view('user/form',$data);
	    }
	    public function group() {
	    	$data = array();
	    	$data['title'] = "user";
	    	$user = $this->model('user');
	    	$listUserGroup = $user->listUserGroup();
	    	$data['listUserGroup'] = $listUserGroup;
 	    	$this->view('user/listGroup',$data);
	    }public function addGroup() {
	    	$data = array();
	    	$data['title'] = "user";
	    	// $user = $this->model('user');
	    	// $listUserGroup = $user->listUserGroup();
	    	// $data['listUserGroup'] = $listUserGroup;
 	    	$this->view('user/formGroup',$data);
	    }
	    public function editGroup() {
	    	$data = array();
	    	$data['title'] = "user";
	    	// $user = $this->model('user');
	    	// $listUserGroup = $user->listUserGroup();
	    	// $data['listUserGroup'] = $listUserGroup;
 	    	$this->view('user/formGroup',$data);
	    }
	    public function deleteGroup(){
	    	// $data = array();
	    	// $data['result'] = 'success';
	    	$result = 'success';
	    	$this->redirect('user/group&result='.$result);
	    }
	}
?>