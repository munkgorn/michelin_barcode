-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Dec 21, 2020 at 06:58 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fsoftpro_barcode`
--

-- --------------------------------------------------------

--
-- Stand-in structure for view `config_day`
-- (See below for the actual view)
--
CREATE TABLE `config_day` (
`config_day` date
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `config_year`
-- (See below for the actual view)
--
CREATE TABLE `config_year` (
`config_year` date
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `freegroup`
-- (See below for the actual view)
--
CREATE TABLE `freegroup` (
`group` int(11)
,`qty` bigint(21)
);

-- --------------------------------------------------------

--
-- Table structure for table `mb_master_barcode`
--

CREATE TABLE `mb_master_barcode` (
  `id_barcode` int(11) NOT NULL,
  `id_user` int(11) DEFAULT NULL,
  `id_group` int(11) DEFAULT NULL,
  `barcode_prefix` int(11) DEFAULT NULL,
  `barcode_code` int(11) DEFAULT NULL,
  `barcode_status` int(1) UNSIGNED ZEROFILL DEFAULT 0,
  `barcode_flag` int(1) UNSIGNED ZEROFILL DEFAULT 0,
  `group_received` int(1) NOT NULL DEFAULT 0,
  `date_added` date DEFAULT NULL,
  `date_modify` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mb_master_barcode_range`
--

CREATE TABLE `mb_master_barcode_range` (
  `id` int(11) NOT NULL,
  `round` int(11) DEFAULT NULL,
  `group_code` int(11) DEFAULT NULL,
  `barcode_start` int(11) DEFAULT NULL,
  `barcode_end` int(11) DEFAULT NULL,
  `barcode_qty` int(11) DEFAULT NULL,
  `barcode_status` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mb_master_config`
--

CREATE TABLE `mb_master_config` (
  `id` int(11) NOT NULL,
  `config_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `config_value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_added` datetime DEFAULT NULL,
  `date_modify` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mb_master_config_barcode`
--

CREATE TABLE `mb_master_config_barcode` (
  `id` int(11) NOT NULL,
  `group` int(11) DEFAULT NULL,
  `start` int(11) DEFAULT NULL,
  `end` int(11) DEFAULT NULL,
  `total` int(11) DEFAULT NULL,
  `remaining` int(11) DEFAULT NULL,
  `now` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_added` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mb_master_config_relationship`
--

CREATE TABLE `mb_master_config_relationship` (
  `id` int(11) NOT NULL,
  `group` int(11) DEFAULT NULL,
  `size` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `comment` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `date_added` datetime DEFAULT NULL,
  `date_modify` datetime DEFAULT NULL,
  `del` int(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mb_master_config_status`
--

CREATE TABLE `mb_master_config_status` (
  `id` int(11) NOT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_added` datetime DEFAULT NULL,
  `date_modify` datetime DEFAULT NULL,
  `del` int(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mb_master_group`
--

CREATE TABLE `mb_master_group` (
  `id_group` int(11) NOT NULL,
  `id_user` int(11) DEFAULT NULL,
  `group_code` int(11) DEFAULT NULL,
  `start` int(11) DEFAULT 0,
  `end` int(11) DEFAULT 0,
  `remaining_qty` int(11) DEFAULT 0,
  `default_start` int(11) DEFAULT 0,
  `default_end` int(11) DEFAULT 0,
  `default_range` int(11) DEFAULT 0,
  `barcode_use` int(11) DEFAULT NULL,
  `config_remaining` int(11) DEFAULT NULL,
  `date_wk` date DEFAULT NULL,
  `del` int(1) DEFAULT 0,
  `date_purchase` date NOT NULL,
  `date_added` date DEFAULT NULL,
  `date_modify` date DEFAULT NULL,
  `change_qty` int(11) NOT NULL,
  `change_end` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mb_master_product`
--

CREATE TABLE `mb_master_product` (
  `id_product` int(11) NOT NULL,
  `id_user` int(11) DEFAULT NULL,
  `id_group` int(11) DEFAULT NULL,
  `size_product_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sum_product` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `product_name` int(11) DEFAULT NULL,
  `remaining_qty` int(11) DEFAULT NULL,
  `propose` int(11) DEFAULT NULL,
  `propose_remaining_qty` int(11) DEFAULT NULL,
  `message` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_wk` date DEFAULT NULL,
  `date_added` date DEFAULT NULL,
  `date_modify` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mb_master_user`
--

CREATE TABLE `mb_master_user` (
  `id_user` int(255) NOT NULL,
  `id_user_group` int(255) DEFAULT NULL,
  `username` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_added` datetime DEFAULT NULL,
  `date_modify` datetime DEFAULT NULL,
  `date_last_login` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mb_master_user_group`
--

CREATE TABLE `mb_master_user_group` (
  `id_user_group` int(255) NOT NULL,
  `group_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_added` datetime DEFAULT NULL,
  `date_modify` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Structure for view `config_day`
--
DROP TABLE IF EXISTS `config_day`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `config_day`  AS SELECT curdate() + interval (-`mb_master_config`.`config_value`) day AS `config_day` FROM `mb_master_config` WHERE `mb_master_config`.`config_key` = 'config_date_size' ;

-- --------------------------------------------------------

--
-- Structure for view `config_year`
--
DROP TABLE IF EXISTS `config_year`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `config_year`  AS SELECT curdate() + interval (-`mb_master_config`.`config_value`) day AS `config_year` FROM `mb_master_config` WHERE `mb_master_config`.`config_key` = 'config_date_year' ;

-- --------------------------------------------------------

--
-- Structure for view `freegroup`
--
DROP TABLE IF EXISTS `freegroup`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `freegroup`  AS SELECT `t`.`group` AS `group`, `t`.`qty` AS `qty` FROM (select `g`.`group_code` AS `group`,(select count(`b`.`id_barcode`) AS `qty` from `mb_master_barcode` `b` where `b`.`barcode_prefix` = `g`.`group_code` and `b`.`group_received` = 1 and `b`.`barcode_flag` = 0 and `b`.`barcode_status` = 0 and `b`.`date_modify` between (select `config_day`.`config_day` from `config_day`) and (select `config_year`.`config_year` from `config_year`) group by `b`.`id_group`,`b`.`barcode_prefix` order by `b`.`id_barcode`,`b`.`id_group`) AS `qty` from `mb_master_group` `g`) AS `t` WHERE `t`.`qty` is not null ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `mb_master_barcode`
--
ALTER TABLE `mb_master_barcode`
  ADD PRIMARY KEY (`id_barcode`) USING BTREE,
  ADD KEY `id_group` (`id_group`) USING BTREE,
  ADD KEY `barcode_prefix` (`barcode_prefix`) USING BTREE,
  ADD KEY `barcode_code` (`barcode_code`) USING BTREE,
  ADD KEY `date_modify` (`id_barcode`) USING BTREE;

--
-- Indexes for table `mb_master_barcode_range`
--
ALTER TABLE `mb_master_barcode_range`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mb_master_config`
--
ALTER TABLE `mb_master_config`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mb_master_config_barcode`
--
ALTER TABLE `mb_master_config_barcode`
  ADD PRIMARY KEY (`id`),
  ADD KEY `group` (`group`) USING BTREE;

--
-- Indexes for table `mb_master_config_relationship`
--
ALTER TABLE `mb_master_config_relationship`
  ADD PRIMARY KEY (`id`),
  ADD KEY `group` (`group`) USING BTREE,
  ADD KEY `size` (`size`) USING BTREE;

--
-- Indexes for table `mb_master_config_status`
--
ALTER TABLE `mb_master_config_status`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mb_master_group`
--
ALTER TABLE `mb_master_group`
  ADD PRIMARY KEY (`id_group`) USING BTREE,
  ADD KEY `id_group` (`id_group`) USING BTREE,
  ADD KEY `group_code` (`group_code`) USING BTREE;

--
-- Indexes for table `mb_master_product`
--
ALTER TABLE `mb_master_product`
  ADD PRIMARY KEY (`id_product`) USING BTREE,
  ADD KEY `id_product` (`id_product`) USING BTREE,
  ADD KEY `id_group` (`id_group`) USING BTREE,
  ADD KEY `size_product_code` (`size_product_code`) USING BTREE;

--
-- Indexes for table `mb_master_user`
--
ALTER TABLE `mb_master_user`
  ADD PRIMARY KEY (`id_user`) USING BTREE;

--
-- Indexes for table `mb_master_user_group`
--
ALTER TABLE `mb_master_user_group`
  ADD PRIMARY KEY (`id_user_group`) USING BTREE;

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `mb_master_barcode`
--
ALTER TABLE `mb_master_barcode`
  MODIFY `id_barcode` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mb_master_config`
--
ALTER TABLE `mb_master_config`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mb_master_config_barcode`
--
ALTER TABLE `mb_master_config_barcode`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mb_master_config_relationship`
--
ALTER TABLE `mb_master_config_relationship`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mb_master_config_status`
--
ALTER TABLE `mb_master_config_status`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mb_master_group`
--
ALTER TABLE `mb_master_group`
  MODIFY `id_group` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mb_master_product`
--
ALTER TABLE `mb_master_product`
  MODIFY `id_product` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mb_master_user`
--
ALTER TABLE `mb_master_user`
  MODIFY `id_user` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mb_master_user_group`
--
ALTER TABLE `mb_master_user_group`
  MODIFY `id_user_group` int(255) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
