<?php 
	class CompanyModel extends db {
		public function submitCompany($data=array()){
			$result = array();
			
			return $result;
		}
	}
?>